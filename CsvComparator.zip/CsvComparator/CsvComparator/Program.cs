﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsvComparator
{
    class Program
    {
        static readonly string primaryFile = @"C:\Users\PrimaryFile.csv";
        static readonly string secondaryFile = @"C:\Users\SecondaryFile.csv";
        static readonly string outputFile = @"C:\Users\Output.csv";

        static void Main(string[] args)
        {
           var pf = FileReader.ReadPrimaryFile(primaryFile);
           var sf=  FileReader.ReadSecondaryFile(secondaryFile);
           var diff = Comparator.Compare(pf, sf);
           FileWriter.WriteOutputFile(diff, outputFile);
        }
    }
}
